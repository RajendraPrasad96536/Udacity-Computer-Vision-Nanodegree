import torch
import torch.nn as nn
import torch.nn.functional as F
# can use the below import should you choose to initialize the weights of your Net
import torch.nn.init as I
import numpy as np


class Net(nn.Module):

    def __init__(self):
        super(Net, self).__init__()
        
        ## TODO: Define all the layers of this CNN, the only requirements are:
        ## 1. This network takes in a square (same width and height), grayscale image as input
        ## 2. It ends with a linear layer that represents the keypoints
        ## it's suggested that you make this last layer output 136 values, 2 for each of the 68 keypoint (x, y) pairs
        
        # As an example, you've been given a convolutional layer, which you may (but don't have to) change:
        # 1 input image channel (grayscale), 32 output channels/feature maps, 5x5 square convolution kernel
        
        self.conv1 = nn.Conv2d(1, 32, 5)
        self.pool1 = nn.MaxPool2d(2, 2)
        self.drop1 = nn.Dropout(p=0.1)
        
        self.conv2 = nn.Conv2d(32, 64, 3)
        self.pool2 = nn.MaxPool2d(2, 2)
        self.drop2 = nn.Dropout(p=0.2)
        
        self.conv3 = nn.Conv2d(64, 128, 3)
        self.pool3 = nn.MaxPool2d(2,2)
        self.drop3 = nn.Dropout(p=0.3)
        
        self.conv4 = nn.Conv2d(128, 256, 3)
        self.pool4 = nn.MaxPool2d(2,2)
        self.drop4 = nn.Dropout(p=0.4)
        
        self.conv5 = nn.Conv2d(256, 512, 3)
        self.pool5 = nn.MaxPool2d(2,2)
        self.drop5 = nn.Dropout(p=0.5)
        
        #self.conv6 = nn.Conv2d(512, 512, 1)
        #self.pool6 = nn.MaxPool2d(2,2)
        #self.drop6 = nn.Dropout(p=0.5)
        
        Input = self.calc() 

        self.fc6 = nn.Linear(Input, 2560)
        self.drop6 = nn.Dropout(p=0.4)
        
        self.fc7 = nn.Linear(2560, 1280)
        self.drop7 = nn.Dropout(p=0.4)

        self.fc8 = nn.Linear(1280, 524)
        self.drop8 = nn.Dropout(p=0.3)

        self.fc9 = nn.Linear(524, 136)

        
        ## Note that among the layers to add, consider including:
        # maxpooling layers, multiple conv layers, fully-connected layers, and other layers (such as dropout or batch normalization) to avoid overfitting
        
    def calc(self) :
        dim = torch.zeros((1,1,227,227))
        dim = self.conv1(dim)
        dim = self.pool1(dim)
        dim = self.conv2(dim)
        dim = self.pool2(dim)
        dim = self.conv3(dim)
        dim = self.pool3(dim)
        dim = self.conv4(dim)
        dim = self.pool4(dim)
        dim = self.conv5(dim)
        dim = self.pool5(dim)
        #dim = self.conv6(dim)
        #dim = self.pool6(dim)
        return int(np.prod(dim.size()))

        
    def forward(self, x):
        ## TODO: Define the feedforward behavior of this model
        ## x is the input image and, as an example, here you may choose to include a pool/conv step:
        
        x = self.pool1(F.relu(self.conv1(x)))
        x = self.drop1(x)
        
        x = self.pool2(F.relu(self.conv2(x)))
        x = self.drop2(x)
        
        x = self.pool3(F.relu(self.conv3(x)))
        x = self.drop3(x)
        
        x = self.pool4(F.relu(self.conv4(x)))
        x = self.drop4(x)
        
        x = self.pool5(F.relu(self.conv5(x)))
        x = self.drop5(x)
        
        #x = F.relu(self.conv6(x))
        # = self.drop6(x)

        x = x.view(x.size(0), -1)
        
        x = F.relu(self.fc6(x))
        x = self.drop6(x)
        
        x = F.relu(self.fc7(x))
        x = self.drop7(x)
        
        x = F.tanh(self.fc8(x))
        x = self.drop8(x)
        
        x = self.fc9(x)

        # a modified x, having gone through all the layers of your model, should be returned
        return x   